from zipfile import ZipFile

# importing required modules
from zipfile import ZipFile
import datetime

# specifying the zip file name
file_name = "C:\\Users\\Rishabh monster\\PycharmProjects\\pyspark\\output\\my_module-1.0-py3.7.egg"

# opening the zip file in READ mode
with ZipFile(file_name, 'r') as zip:
    for info in zip.infolist():
        print(info.filename)