# Copilot / AI Agent Instructions for devinpoc-main

Purpose: a short, focused guide so an AI coding agent can be immediately productive in this codebase.

Quick summary (big picture)
- This is a small PySpark ETL pipeline framework driven by JSON configuration files (see `src/util/read_json.py` and `src/util/Component.py`).
- Components (Input, Join, Sort, Filter, Output, Rollup, DedupSort, Scan, Lookup, Merge, Partition) are implemented as classes that inherit `src.etl.Component.ComponentInfo` and expose an `execute()` method (examples: `src/input/InputCSVFileComponent.py`, `src/join/JoinComponent.py`, `src/sort/SortComponent.py`, `src/output/OutputCSVComponent.py`).
- A central Driver (`src/etl/SparkDriver.py`) uses `ComponentDriver` to instantiate component objects via factory classes in `src/factory/*` and builds a dependency list consumed by the Luigi-based workflow (`src/workflow/luigi_Workflow.py`).
- Runtime sharing of intermediate DataFrames is via the global map `SparkAbstract.mapDf` (`src/etl/SparkAbstract.py`). Components put/read DataFrames into this map by component id.

How the pipeline is assembled and executed (step-by-step)
1. A JSON file describing components is loaded with `read_json.read_json_config()` and parsed into `Component` objects (`src/util/read_json.py`, `src/util/Component.py`). JSON entries must match the `Component` dataclass-like constructor keys.
2. `DriverProgram.getAllConfig()` (in `src/etl/SparkDriver.py`) calls `ComponentDriver(...)` to create runnable component objects and then resolves dependencies into an ordered `DriverProgram.dependecylist` using `node_reference` fields and `src/util/CheckNode.py` logic.
3. Luigi tasks in `src/workflow/luigi_Workflow.py` (`EnqueueTask` / `ExecutorTask`) are called to run components in the resolved order. (Note: Luigi invocation in `src/etl/SparkMain.py` is currently commented out — the code still builds `dependecylist`.)
4. `SparkMain.py` is the entry point which initializes Spark (via `src/util/getSpark.py`) and kicks off the Driver.

Important files to read first (examples to reference in edits)
- `src/util/Component.py` — shape of the configuration object used throughout.
- `src/util/read_json.py` — how JSON is parsed into Component objects.
- `src/etl/SparkAbstract.py` — global DataFrame store (`mapDf`) used by components.
- `src/etl/ComponentDriver.py` — wiring: map component_type -> factory -> component instance.
- `src/factory/*` — factory classes that instantiate components (pattern to follow when adding a new component).
- Concrete components: `src/input/InputCSVFileComponent.py`, `src/join/JoinComponent.py`, `src/sort/SortComponent.py`, `src/output/OutputCSVComponent.py`.

How to run / dev commands (practical)
- Requirements: this project expects Python + PySpark and Luigi available in your environment.
- To run locally (quick): cd into `src/etl` and run the Spark entry script with a JSON filename (the script expects `../application.properties` to exist and contain `basicdetail.jsonfilepath`):

```bash
cd src/etl
python SparkMain.py <json_filename.json>
```

- To build a distributable egg (project contains helper):

```bash
cd src
python create_egg.py   # produces an egg under `src/output/`
```

Project-specific conventions and patterns (do not change without aligning other modules)
- Component identity and reference
  - Every component instance has an `id` (string) used as the key in `SparkAbstract.mapDf` and in SQL temp view names. IDs are used verbatim in SQL; prefer IDs that are valid SQL identifiers (no spaces/special chars).
  - `node_reference` is a list of component ids that the current component reads from. This is the dependency graph used by `SparkDriver`.
- Factories
  - Each component type has a factory in `src/factory/*`. When adding a component follow this: implement the component class, add a simple factory (returning an instance), and register it in `src/etl/ComponentDriver.py`.
- Shared DataFrames
  - Components read/write DataFrames using `SparkAbstract.addToDict(component_id, df)` and read via `SparkAbstract.mapDf[component_id]`.
- SQL construction
  - Several components (Join, Sort) construct SQL strings using component ids and join conditions (e.g., `JoinComponent` builds a SELECT with fully qualified column names like `{component}.{column}`). Expect string-based SQL composition.

Common edits and how to implement them (concrete recipe)
- Add a new component type:
  1. Create `src/<type>/<MyComponent>.py` subclassing `ComponentInfo` and implement `execute(self)` — follow `InputCSVFile` or `JoinComponent` as examples.
  2. Create `src/factory/<MyComponent>Factory.py` with a `get<MyComponent>Component(self, component, spark)` returning the component instance.
  3. Wire the new type in `src/etl/ComponentDriver.py`: add an `elif (ComponentInfo.component_type).upper() == '<MYTYPE>'` branch that calls the factory.
  4. Update JSON config files to use `component_type` value matching the check used in `ComponentDriver`.

Pitfalls, gotchas, and debugging tips
- Global state: `SparkAbstract.mapDf` is global and mutable; tests or sequential runs should clear or restart the process to avoid stale data.
- Relative paths: `SparkMain.py` reads `../application.properties` relative to the `src/etl` folder. Run the script from `src/etl` or adjust paths accordingly.
- SQL safety: components build SQL by string concatenation. When changing how columns or ids are created, ensure identifiers remain valid SQL identifiers.
- Luigi integration: Luigi invocation is present but currently commented out in `SparkMain.py`; the code still produces a `dependecylist` you can use to run tasks manually or enable the Luigi block.
- Schema handling: `InputCSVFileComponent` uses `src/util/SchemaHandler.get_schema()` when a schema file path is provided; schemas are expected in `src/data` or specified paths.

Quick examples to cite in prompts
- "To read input CSV data into the pipeline, follow `InputCSVFile.execute()` which does a spark.read.format('csv')... and then calls `SparkAbstract.addToDict(id, df)` so downstream components can reference `id`."
- "To add a Join, look at `JoinComponent.execute()` — it creates temp views named after input ids, composes an SQL join string using `join_conditions`, runs `spark.sql()` and writes result to `SparkAbstract.mapDf` under the component id."

Next steps / how I validated
- I scanned key files: `src/etl/*`, `src/util/*`, component implementations under `src/input`, `src/join`, `src/sort`, `src/output`, and the factory modules to produce the above recommendations.

If anything looks incomplete or you want the instructions tailored for a different level of detail (for example, include exact JSON samples or a template for adding components), tell me which section to expand and I will update the file.
